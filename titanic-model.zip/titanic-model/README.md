# Titanic Survival Model

Random Forest classifier for the Kaggle "Titanic - Machine Learning from Disaster" competition.

## Quick start

```bash
pip install -r requirements.txt
python titanic.py
```

This downloads the data into `data/` if needed, prints 10-fold cross-validation accuracy,
and writes `submission.csv` (columns `PassengerId,Survived`) ready to upload to Kaggle.

To use the official Kaggle files, place `train.csv` and `test.csv` in `data/`.

## Model

- `RandomForestClassifier` (500 trees, max depth 7, min 3 samples per leaf)
- Features: passenger class, sex, age (imputed by title and class), family size,
  travelling alone, fare per person, ticket group size, title from name, cabin deck, port of embarkation

## Results

Cross-validation accuracy is about 0.83 on the training data. Expect a lower Kaggle
leaderboard score (roughly 0.77-0.80), since the test labels are hidden.
