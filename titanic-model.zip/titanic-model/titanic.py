"""Titanic survival prediction with a Random Forest.

Usage:
    python titanic.py                      # uses data/train.csv and data/test.csv
    python titanic.py --data-dir mydata    # custom folder
    python titanic.py --output out.csv

If the CSVs are missing, they are downloaded from public GitHub mirrors.
Put the official Kaggle train.csv / test.csv in data/ to use those instead.
"""
import argparse
import urllib.request
from pathlib import Path

import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_score

URLS = {
    "train.csv": "https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv",
    "test.csv": "https://raw.githubusercontent.com/agconti/kaggle-titanic/master/data/test.csv",
}
SEED = 1


def load_data(data_dir: Path):
    data_dir.mkdir(parents=True, exist_ok=True)
    for name, url in URLS.items():
        path = data_dir / name
        if not path.exists():
            print(f"Downloading {name} ...")
            urllib.request.urlretrieve(url, path)
    return pd.read_csv(data_dir / "train.csv"), pd.read_csv(data_dir / "test.csv")


def build_features(train: pd.DataFrame, test: pd.DataFrame):
    df = pd.concat([train, test], ignore_index=True)

    title = df.Name.str.extract(r" ([A-Za-z]+)\.", expand=False)
    title = title.replace({"Mlle": "Miss", "Ms": "Miss", "Mme": "Mrs"})
    df["Title"] = title.where(title.isin(["Mr", "Mrs", "Miss", "Master"]), "Rare")

    df["Fam"] = df.SibSp + df.Parch + 1
    df["Alone"] = (df.Fam == 1).astype(int)
    df["Fare"] = df.Fare.fillna(df.groupby("Pclass").Fare.transform("median"))
    df["TicketN"] = df.groupby("Ticket").Ticket.transform("count")
    df["FarePP"] = df.Fare / df.TicketN
    df["Age"] = df.Age.fillna(df.groupby(["Title", "Pclass"]).Age.transform("median"))
    df["Age"] = df.Age.fillna(df.Age.median())
    df["Deck"] = df.Cabin.str[0].fillna("U")
    df["Emb"] = df.Embarked.fillna("S")
    df["Sex_i"] = (df.Sex == "female").astype(int)

    cols = ["Pclass", "Sex_i", "Age", "Fam", "Alone", "FarePP",
            "Title", "Deck", "Emb", "TicketN"]
    X = pd.get_dummies(df[cols], drop_first=True).astype(float)
    n = len(train)
    return X.iloc[:n], X.iloc[n:]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default="data")
    ap.add_argument("--output", default="submission.csv")
    args = ap.parse_args()

    train, test = load_data(Path(args.data_dir))
    X_train, X_test = build_features(train, test)
    y = train.Survived

    model = RandomForestClassifier(
        n_estimators=500, max_depth=7, min_samples_leaf=3,
        random_state=SEED, n_jobs=-1,
    )
    cv = StratifiedKFold(n_splits=10, shuffle=True, random_state=SEED)
    scores = cross_val_score(model, X_train, y, cv=cv)
    print(f"10-fold CV accuracy: {scores.mean():.4f} (+/- {scores.std():.4f})")

    model.fit(X_train, y)
    preds = model.predict(X_test)
    pd.DataFrame({"PassengerId": test.PassengerId, "Survived": preds}).to_csv(
        args.output, index=False
    )
    print(f"Saved {len(preds)} predictions to {args.output}")


if __name__ == "__main__":
    main()
