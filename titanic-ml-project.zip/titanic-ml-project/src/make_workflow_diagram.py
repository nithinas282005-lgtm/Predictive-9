import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
steps=[("Raw data\ntrain.csv / test.csv","#1F4E79"),("EDA &\ndata cleaning","#2E86AB"),("Feature engineering\nTitle, FamilySize,\nIsAlone, HasCabin","#2E86AB"),("Imputation &\nencoding","#2E86AB"),("Models\nLogReg · RF · GBM","#E07A5F"),("5-fold CV\n& tuning","#E07A5F"),("Ensemble /\nbest model","#E07A5F"),("submission.csv\n→ Kaggle","#1F4E79")]
fig,ax=plt.subplots(figsize=(12,3.6));ax.axis("off");ax.set_xlim(0,12);ax.set_ylim(0,3.6)
pos=[(0.1,2.0),(3.1,2.0),(6.1,2.0),(9.1,2.0),(9.1,0.2),(6.1,0.2),(3.1,0.2),(0.1,0.2)]
for (t,c),(x,y) in zip(steps,pos):
    ax.add_patch(FancyBboxPatch((x,y),2.8,1.2,boxstyle="round,pad=0.03,rounding_size=0.12",fc=c,ec="none"))
    ax.text(x+1.4,y+0.6,t,ha="center",va="center",color="white",fontsize=11,fontweight="bold")
for i in range(7):
    (x1,y1),(x2,y2)=pos[i],pos[i+1]
    if y1==y2==2.0: a=((x1+2.85,y1+0.6),(x2-0.05,y2+0.6))
    elif y1==y2: a=((x1-0.05,y1+0.6),(x2+2.85,y2+0.6))
    else: a=((x1+1.4,y1-0.05),(x2+1.4,y2+1.25))
    ax.add_patch(FancyArrowPatch(*a,arrowstyle="-|>",mutation_scale=18,color="#444",lw=2))
plt.tight_layout();plt.savefig("figures/flow.png",dpi=200)
