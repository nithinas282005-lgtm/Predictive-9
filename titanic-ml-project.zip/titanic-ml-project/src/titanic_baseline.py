"""EDA + baseline models with stratified 5-fold CV.

Usage:  python src/titanic_baseline.py  [--data data/train.csv]
Outputs: results/results.json, figures/eda.png, figures/imp.png
"""
import argparse, json
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from features import engineer, design_matrix

SEED = 42


def main(path):
    df = pd.read_csv(path)
    y = df.Survived
    res = {"n": len(df), "survival_rate": float(y.mean()),
           "by_sex": df.groupby("Sex").Survived.mean().to_dict(),
           "by_pclass": {int(k): v for k, v in df.groupby("Pclass").Survived.mean().items()},
           "missing": {c: int(df[c].isna().sum()) for c in ["Age", "Cabin", "Embarked"]}}

    # raw-feature baseline (median Age only)
    raw = df.copy()
    raw["Age"] = raw.Age.fillna(raw.Age.median())
    X_raw = pd.get_dummies(raw[["Pclass", "Sex", "Age", "SibSp", "Parch", "Fare"]], drop_first=True)
    d = engineer(df)
    X = design_matrix(d)

    cv = StratifiedKFold(5, shuffle=True, random_state=SEED)
    lr = lambda: make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000))
    runs = {
        "LogReg (raw)": (lr(), X_raw),
        "LogReg (+FE)": (lr(), X),
        "RandomForest (+FE)": (RandomForestClassifier(300, max_depth=6, min_samples_leaf=3, random_state=SEED), X),
        "GradBoost (+FE)": (GradientBoostingClassifier(n_estimators=150, max_depth=3, learning_rate=0.05, random_state=SEED), X),
    }
    res["cv_accuracy"] = {"Gender-only rule": float(((df.Sex == "female").astype(int) == y).mean())}
    for name, (model, feats) in runs.items():
        s = cross_val_score(model, feats, y, cv=cv, scoring="accuracy")
        res["cv_accuracy"][name] = [float(s.mean()), float(s.std())]
        print(f"{name:22s} {s.mean():.4f} +/- {s.std():.4f}")
    print(f"{'Gender-only rule':22s} {res['cv_accuracy']['Gender-only rule']:.4f}")

    rf = runs["RandomForest (+FE)"][0].fit(X, y)
    imp = pd.Series(rf.feature_importances_, index=X.columns).sort_values(ascending=False)
    res["rf_importance_top8"] = imp.head(8).round(3).to_dict()
    json.dump(res, open("results/results.json", "w"), indent=1)

    fig, ax = plt.subplots(1, 3, figsize=(11, 3.4))
    df.groupby("Sex").Survived.mean().plot.bar(ax=ax[0], color="#1F4E79", rot=0, title="Survival by sex")
    df.groupby("Pclass").Survived.mean().plot.bar(ax=ax[1], color="#2E86AB", rot=0, title="Survival by class")
    d.groupby("FamilySize").Survived.mean().plot.bar(ax=ax[2], color="#E07A5F", rot=0, title="Survival by family size")
    for a in ax:
        a.set_ylim(0, 1); a.set_ylabel("Rate"); a.spines[["top", "right"]].set_visible(False)
    plt.tight_layout(); plt.savefig("figures/eda.png", dpi=200); plt.close()

    fig, ax = plt.subplots(figsize=(6, 3.4))
    imp.head(8)[::-1].plot.barh(ax=ax, color="#1F4E79", title="Random Forest feature importance")
    ax.spines[["top", "right"]].set_visible(False)
    plt.tight_layout(); plt.savefig("figures/imp.png", dpi=200)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/train.csv")
    main(ap.parse_args().data)
