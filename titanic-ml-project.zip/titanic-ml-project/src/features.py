"""Shared pre-processing and feature engineering for the Titanic project."""
import pandas as pd

FEATURES = ["Pclass", "Sex", "Age", "Fare", "FamilySize", "IsAlone",
            "HasCabin", "Embarked", "Title"]


def engineer(df: pd.DataFrame) -> pd.DataFrame:
    """Return a copy of df with cleaned values and engineered features."""
    d = df.copy()
    d["Title"] = d.Name.str.extract(r",\s*([^\.]+)\.")[0].str.strip()
    d["Title"] = d.Title.replace({"Mlle": "Miss", "Ms": "Miss", "Mme": "Mrs"})
    d["Title"] = d.Title.where(d.Title.isin(["Mr", "Mrs", "Miss", "Master"]), "Rare")
    d["FamilySize"] = d.SibSp + d.Parch + 1
    d["IsAlone"] = (d.FamilySize == 1).astype(int)
    # Age: median of the passenger's Title x Pclass group, then global median
    d["Age"] = d.groupby(["Title", "Pclass"]).Age.transform(lambda s: s.fillna(s.median()))
    d["Age"] = d.Age.fillna(d.Age.median())
    d["Embarked"] = d.Embarked.fillna("S")
    d["Fare"] = d.Fare.fillna(d.Fare.median())
    d["HasCabin"] = d.Cabin.notna().astype(int)
    return d


def design_matrix(d: pd.DataFrame) -> pd.DataFrame:
    """One-hot encode the engineered features."""
    return pd.get_dummies(d[FEATURES], drop_first=True)
