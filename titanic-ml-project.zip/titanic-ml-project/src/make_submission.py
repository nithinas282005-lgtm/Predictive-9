"""Train on train.csv and write a Kaggle submission for test.csv.

Usage: python src/make_submission.py [--train data/train.csv] [--test data/test.csv] [--out submission.csv]
Model: Gradient Boosting on the engineered features (current best CV score).
"""
import argparse
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier
from features import engineer, design_matrix


def main(train_path, test_path, out):
    tr, te = pd.read_csv(train_path), pd.read_csv(test_path)
    both = pd.concat([tr.drop(columns="Survived"), te], keys=["tr", "te"])
    X = design_matrix(engineer(both.reset_index(drop=True)))
    X_tr, X_te = X.iloc[:len(tr)], X.iloc[len(tr):]
    model = GradientBoostingClassifier(n_estimators=150, max_depth=3, learning_rate=0.05, random_state=42)
    model.fit(X_tr, tr.Survived)
    pd.DataFrame({"PassengerId": te.PassengerId, "Survived": model.predict(X_te)}).to_csv(out, index=False)
    print(f"Wrote {out} ({len(te)} rows)")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--train", default="data/train.csv")
    ap.add_argument("--test", default="data/test.csv")
    ap.add_argument("--out", default="submission.csv")
    a = ap.parse_args()
    main(a.train, a.test, a.out)
