# Titanic – Machine Learning from Disaster

Progress submission (v1, 12 October 2026) for the Kaggle competition
[Titanic – Machine Learning from Disaster](https://www.kaggle.com/competitions/titanic).

**Team**

| Name | Roll No. |
|---|---|
| Avinash | 23MID0344 |
| Rohith | 23MID0270 |
| Nithin | 23MID0325 |
| Moureesh | 23MID0368 |

## Problem
Binary classification: predict whether a passenger survived (`Survived` = 1/0) from
`Pclass, Sex, Age, SibSp, Parch, Fare, Cabin, Embarked, Name, Ticket`.
Train: 891 rows, test: 418 rows. Metric: accuracy.

## Workflow
![Workflow](figures/flow.png)

Feature engineering (`src/features.py`): `Title` (from Name), `FamilySize`, `IsAlone`,
`HasCabin`; Age imputed by Title x Pclass median; one-hot encoding.

## Results so far (stratified 5-fold CV on train.csv, seed 42)

| Model | CV accuracy |
|---|---|
| Gender-only rule | 78.7% |
| Logistic regression, raw features | 78.9% (±1.1) |
| Logistic regression + engineered features | 83.6% (±1.1) |
| Random Forest + engineered features | 83.4% (±1.1) |
| Gradient Boosting + engineered features | 83.7% (±1.9) |

The three engineered-feature models are within one standard deviation of each other.
No Kaggle leaderboard score yet.

![EDA](figures/eda.png)

## How to run
```bash
pip install -r requirements.txt
# 1. Download train.csv and test.csv from the Kaggle competition page into data/
python src/titanic_baseline.py      # EDA + CV results -> results/, figures/
python src/make_submission.py       # writes submission.csv for Kaggle
python src/make_workflow_diagram.py # regenerates figures/flow.png
```
Run the scripts from the repository root. The data files are not included
(download them from Kaggle; they are git-ignored).

## Repository layout
```
src/       features.py, titanic_baseline.py, make_submission.py, make_workflow_diagram.py
figures/   EDA, feature-importance and workflow figures
results/   results.json (CV scores)
docs/      Report v1 (.docx) and presentation v1 (.pptx)
data/      put train.csv / test.csv here
```

## Next steps
Hyper-parameter tuning, XGBoost/LightGBM, extra features (ticket group, fare per person,
deck), ensembling, first Kaggle submission, error analysis.
